clc;clear;close all;
path(path,genpath(pwd));

Nbiter= 175;	
lambda = 0.25; 	
tau = 0.01;	

maindir = 'D:/Denoise/subject/matlab/ImprovedTVAlgorithms/image_p/ori_img/';
subdirpath = fullfile( maindir, '*.png' );
images = dir( subdirpath );
     
    % 遍历每张图片
for j = 1 : length( images )
    imagepath = fullfile( maindir, images( j ).name  )
    imgdata = imread( imagepath );   % 这里进行你的读取操作
%         rgb=imread(file); %读入图像
    mysize1=size(imgdata);
    if numel(mysize1)>2
        y1 = rgb2gray(imgdata); %将彩色图像转换为灰度图像
    else
        y1 = imgdata;
    end

    imgpath =  fullfile('D:/Denoise/subject/matlab/ImprovedTVAlgorithms/deal_bw/di_er/',strcat('de',images( j ).name))
    imgdata2 = imread( imgpath );
    mysize2=size(imgdata2);
    if numel(mysize2)>2
        y2 = rgb2gray(imgdata2); %将彩色图像转换为灰度图像
    else
        y2 = imgdata2;
    end
    y2 = imresize(y2,[mysize1(1,1),mysize1(1,2)]);
    y = 0.6*y1+0.4*y2;
    y = double(y)/255; 
 
    t = cputime;
    x = TVdenoising(y,lambda,tau,Nbiter); 
    t = cputime-t;
    fprintf(num2str(t));

    SSIM = ssim(x,y)
    PSNR = psnr(x,y)

    figure();
    imshow(x,[]);
    %path1 = fullfile( 'D:/Denoise/subject/matlab/ImprovedTVAlgorithms/image_p/TV_pro/',strcat('TV_de',num2str(PSNR),' dB_',num2str(SSIM),'_',num2str(Nbiter),'_',num2str(lambda),'_',num2str(t),'s_',images( j ).name ))
    %imwrite(x,path1);
    title(strcat(['TV_improved, ','PSNR = ',num2str(PSNR),'dB']));

end
    