clc;                
clear;            
maindir = 'D:/Denoise/subject/matlab/ImprovedTVAlgorithms/image_p/ori_img/';
subdirpath = fullfile( maindir, '*.png' );
images = dir( subdirpath );  


for j = 1 : length( images )
    imagepath = fullfile( maindir, images( j ).name  )
    imgdata = imread( imagepath );   % 这里进行你的读取操作

    se=strel('ball',3,1);
    i2=imdilate(imgdata, se);             %进行膨胀处理
%     subplot(1,2,1);
%     imshow(imgdata);
%     title('ori') ;
%     subplot(1,2,2);
%     imshow(i2);
    maindir1 = 'D:/Denoise/subject/matlab/ImprovedTVAlgorithms/deal_bw/dilate/';
    path1 = fullfile( maindir1, strcat('d',images( j ).name)  )
    imwrite(i2,path1);
    title('dilate')



    dimg=imread(path1);                 %读取图像
    se=strel('ball',3,11);
    i3=imerode(dimg, se);          %对灰度图像进行腐蚀
%     subplot(1,2,1);
%     imshow(dimg);
%     title('erode') ;
%     subplot(1,2,2);
%     imshow(i3);
    path2 = fullfile( 'D:/Denoise/subject/matlab/ImprovedTVAlgorithms/deal_bw/di_er/', strcat('de',images( j ).name)  )
    imwrite(i3,path2);
    title('dier') ;

end 

