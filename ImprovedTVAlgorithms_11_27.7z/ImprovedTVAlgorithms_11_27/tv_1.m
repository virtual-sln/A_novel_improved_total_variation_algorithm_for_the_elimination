clc;clear all;
path(path,genpath(pwd));

clc;clear;close all;
path(path,genpath(pwd));

Nbiter= 175;	% number of iterations
lambda = 0.25; 	% regularization parameter
tau = 0.01;		% proximal parameter >0; influences the
		% convergence speed
		
% 	y  = double(imread('1.png'))/255;   % Initial image
%     img = imread('21_11.png');
%     img1 = imread('e21_11.png');
maindir = 'D:/Denoise/subject/matlab/image_deal/final_deal/';
% subdirpath = fullfile( maindir, '*.png' );
% images = dir( subdirpath );  
subdir =  dir( maindir );   % 先确定子文件夹
      
for i = 1 : length( subdir )
    
    % 文件夹下多个子文件用
    if( isequal( subdir( i ).name, '.' ) || ...
        isequal( subdir( i ).name, '..' ) || ...
        ~subdir( i ).isdir )   % 如果不是目录跳过
        continue;
    end
      
    subdirpath = fullfile( maindir, subdir( i ).name, '*.jpg' );
    images = dir( subdirpath );   % 在这个子文件夹下找后缀为jpg的文件
     
    % 遍历每张图片
    for j = 1 : length( images )
        imagepath = fullfile( maindir, subdir( i ).name, images( j ).name  )
        imgdata = imread( imagepath );   % 这里进行你的读取操作
        
%         rgb=imread(file); %读入图像
        mysize1=size(imgdata);
        if numel(mysize1)>2
            y1 = rgb2gray(imgdata); %将彩色图像转换为灰度图像
        else
            y1 = imgdata;
        end
        
        
        imgpath =  fullfile('D:/Denoise/subject/matlab/TotalVariationAlgorithms-master/论文图片/deal/bw/di_er/di_er1/',subdir( i ).name,strcat('de',images( j ).name))
        imgdata2 = imread( imgpath );
        mysize2=size(imgdata2);
        if numel(mysize2)>2
            y2 = rgb2gray(imgdata2); %将彩色图像转换为灰度图像
        else
            y2 = imgdata2;
        end
        y2 = imresize(y2,[mysize1(1,1),mysize1(1,2)]);
        
        y = 0.6*y1+0.4*y2;
%         y = y1;
        y = double(y)/255; % 归一化

%         figure(1);
%         imshow(y);
%         title('原图');
        
        t = cputime;
        x = TVdenoising(y,lambda,tau,Nbiter);  %    TV处理
        t = cputime-t;
        fprintf(num2str(t));
        
%         [PSNR, MSE] = psnr(x, y)
        %{
        x1subdirpath = fullfile('D:/Denoise/subject/matlab/TotalVariationAlgorithms-master/论文图片/tv/tv2/tvv/', images( j ).name);
%         x1path= dir( x1subdirpath );   % 在这个子文件夹下找后缀为jpg的文件
        x1=imread(x1subdirpath);
        x=(double(x1)+x2)/2;
        PSNR = 20*log10(255/sqrt(mean((x(:)/255-y(:)/255).^2)));
        %}
%         PSNR = 20*log10(255/sqrt(mean((x(:)-y(:)).^2)))
%         PSNR = 20*log10(255/sqrt((mean(x(:)-(y(:))/255).^2)));
        SSIM = ssim(x,y)
        PSNR = psnr(x,y)
%         fprintf(num2str(PSNR));
%         figure();
%         imshow(x,[]);
        path1 = fullfile( 'D:/Denoise/subject/matlab/TotalVariationAlgorithms-master/论文图片/deal/bw/di_er/TV_de/', subdir( i ).name, strcat('TV_de',num2str(PSNR),' dB_',num2str(SSIM),'_',num2str(Nbiter),'_',num2str(lambda),'_',num2str(t),'s_',images( j ).name ))
        imwrite(x,path1);
        title(strcat(['TV_improved, ','PSNR = ',num2str(PSNR),'dB']));
        
    end
    end



%{
Nbiter= 100;	% number of iterations
lambda = 0.15; 	% regularization parameter
tau = 0.01;		% proximal parameter >0; influences the
		% convergence speed
		
% 	y  = double(imread('1.png'))/255;   % Initial image
img = imread('D:/Denoise/subject/matlab/TotalVariationAlgorithms-master//论文图片/原图/21_12.png');
figure
imshow(img)
% img1 = imread('e31_2.png');

mysize=size(img);
if numel(mysize)>2
            y1 = rgb2gray(img); %将彩色图像转换为灰度图像
        else
            y1 = img;
end
        
% mysize1=size(img1);
% if numel(mysize1)>2
%             y2 = rgb2gray(img1); %将彩色图像转换为灰度图像
%         else
%             y2 = img1;
% end
%         
% y = 1*y1+0*y2;
y = double(y1)/255; % 归一化

figure(1);
imshow(y);
title('原图');

x = TVdenoising(y,lambda,tau,Nbiter);  %    TV处理

PSNR = 20*log10(255/sqrt(mean((x(:)-y(:)).^2)));
fprintf(num2str(PSNR));
figure();
imshow(x);
path1 = fullfile( 'D:/Denoise/subject/matlab/TotalVariationAlgorithms-master/论文图片/tv/tv2/',strcat('TV_',num2str(PSNR),' dB_',num2str(Nbiter),'_',num2str(lambda),'_','21_12.png' ))
imwrite(x,path1);
title(strcat(['TV_improved, ','PSNR = ',num2str(PSNR),'dB']));
%}
        